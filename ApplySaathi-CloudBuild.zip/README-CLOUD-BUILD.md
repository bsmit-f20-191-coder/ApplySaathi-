# ApplySaathi — Cloud Build

This project is prepared for cloud Android builds and does not require Android Studio on the user's iPhone.

## GitHub Actions

The workflow at `.github/workflows/android.yml` builds:

- Debug APK: `app/build/outputs/apk/debug/*.apk`
- Release AAB: `app/build/outputs/bundle/release/*.aab`

It uses JDK 17 and Gradle 8.11.1.

## Codemagic

`codemagic.yaml` provides the same cloud build path and publishes the AAB as a build artifact.

## Important for Google Play

The current release build is not Play Store-signed yet. Before publishing, configure a release keystore and signing secrets in the chosen cloud CI provider. Never commit the keystore or passwords to the repository.
