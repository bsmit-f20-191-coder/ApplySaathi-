package com.applysaathi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF168A52)
private val LightGreen = Color(0xFFEAF7F0)

data class Opportunity(val title:String,val org:String,val location:String,val deadline:String,val category:String)
val opportunities = listOf(
 Opportunity("Punjab Government Internship Program","Government of Punjab","Lahore","20 Oct 2026","Internships"),
 Opportunity("HEC Need Based Scholarship","Higher Education Commission","Pakistan","31 Oct 2026","Scholarships"),
 Opportunity("Junior Software Developer","Technology Company","Lahore / Remote","25 Oct 2026","Jobs"),
 Opportunity("BS Admissions 2026","Leading University","Lahore","15 Nov 2026","Admissions")
)

class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{ApplySaathiApp()}}}

@Composable fun ApplySaathiApp(){
 var tab by remember{mutableStateOf(0)}; var selected by remember{mutableStateOf<Opportunity?>(null)}
 MaterialTheme(colorScheme=lightColorScheme(primary=Green)){
  Surface(Modifier.fillMaxSize(),color=Color.White){
   if(selected!=null) Details(selected!!,{selected=null}) else {
    Column(Modifier.fillMaxSize()){
     Box(Modifier.weight(1f)){ when(tab){0->Home{selected=it};1->Explore{selected=it};2->Saved();else->Applications()} }
     NavigationBar(containerColor=Color.White){ listOf("⌂" to "Home","⌕" to "Explore","♡" to "Saved","✓" to "Applications").forEachIndexed{ i,p->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(p.first,fontSize=22.sp)},label={Text(p.second)}) } }
    }
   }
  }
 }
}

@Composable fun Header(){ Row(Modifier.fillMaxWidth().padding(20.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("ApplySaathi",fontSize=26.sp,fontWeight=FontWeight.Bold,color=Green);Text("Your opportunity partner",color=Color.Gray)}Text("🔔",fontSize=24.sp)} }
@Composable fun Home(onOpen:(Opportunity)->Unit){ LazyColumn(contentPadding=PaddingValues(bottom=20.dp)){item{Header();Text("Assalam-o-Alaikum 👋",Modifier.padding(horizontal=20.dp),fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Find the right opportunity for you",Modifier.padding(20.dp,4.dp),color=Color.Gray);SearchBox()};item{Text("Categories",Modifier.padding(20.dp,18.dp,20.dp,10.dp),fontWeight=FontWeight.Bold,fontSize=18.sp);Row(Modifier.padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){listOf("💼 Jobs","🎓 Scholarships","🏫 Admissions").forEach{Category(it)}}};item{Text("Featured Opportunities",Modifier.padding(20.dp),fontWeight=FontWeight.Bold,fontSize=18.sp)};items(opportunities){OpportunityCard(it,onOpen)} } }
@Composable fun SearchBox(){Surface(Modifier.fillMaxWidth().padding(horizontal=20.dp),shape=RoundedCornerShape(16.dp),color=Color(0xFFF4F5F5)){Text("🔎  Search jobs, scholarships, admissions...",Modifier.padding(16.dp),color=Color.Gray)} }
@Composable fun Category(t:String){Surface(Modifier.weight(1f).height(75.dp),shape=RoundedCornerShape(16.dp),color=LightGreen){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text(t,fontSize=12.sp,fontWeight=FontWeight.SemiBold)}}}
@Composable fun OpportunityCard(o:Opportunity,onOpen:(Opportunity)->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=6.dp).clickable{onOpen(o)},shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(o.category.uppercase(),color=Green,fontSize=11.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Text("♡",fontSize=22.sp)};Text(o.title,Modifier.padding(top=7.dp),fontSize=18.sp,fontWeight=FontWeight.Bold);Text(o.org,color=Color.Gray);Text("📍 ${o.location}   •   📅 ${o.deadline}",Modifier.padding(top=10.dp),fontSize=12.sp);Text("View Details →",Modifier.padding(top=12.dp),color=Green,fontWeight=FontWeight.Bold)}}}
@Composable fun Explore(onOpen:(Opportunity)->Unit){LazyColumn(contentPadding=PaddingValues(16.dp)){item{Text("Explore Opportunities",fontSize=26.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(14.dp));SearchBox();Spacer(Modifier.height(16.dp));Text("Filters:  All   Jobs   Scholarships   Admissions   Internships",color=Green,fontSize=13.sp);Spacer(Modifier.height(10.dp))};items(opportunities){OpportunityCard(it,onOpen)}}}
@Composable fun Details(o:Opportunity,onBack:()->Unit){Column(Modifier.fillMaxSize().padding(20.dp)){Text("‹  Back",color=Green,fontWeight=FontWeight.Bold,Modifier.clickable{onBack()});Spacer(Modifier.height(20.dp));Text(o.title,fontSize=28.sp,fontWeight=FontWeight.Bold);Text(o.org,color=Color.Gray,Modifier.padding(top=6.dp));Text("📍 ${o.location}\n📅 Deadline: ${o.deadline}",Modifier.padding(top=18.dp));Text("About this opportunity",Modifier.padding(top=28.dp),fontSize=20.sp,fontWeight=FontWeight.Bold);Text("This opportunity is available through ApplySaathi. Check eligibility and required documents before applying.",Modifier.padding(top=8.dp),color=Color.DarkGray);Text("Eligibility",Modifier.padding(top=24.dp),fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Relevant education, age and other requirements as specified by the organization.",Modifier.padding(top=8.dp),color=Color.DarkGray);Spacer(Modifier.weight(1f));Button(onClick={},Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(16.dp)){Text("Apply Now",fontSize=17.sp)}}}
@Composable fun Saved(){EmptyState("🔖","No saved opportunities yet","Save opportunities here to apply later.")}
@Composable fun Applications(){EmptyState("📋","No applications yet","Your submitted applications will appear here.")}
@Composable fun EmptyState(icon:String,title:String,msg:String){Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(icon,fontSize=48.sp);Text(title,fontSize=22.sp,fontWeight=FontWeight.Bold,Modifier.padding(top=14.dp));Text(msg,color=Color.Gray,Modifier.padding(top=8.dp))}}
